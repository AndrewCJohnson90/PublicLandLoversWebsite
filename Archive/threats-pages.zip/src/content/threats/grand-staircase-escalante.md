---
title: "Grand Staircase-Escalante"
description: "What's at risk for Grand Staircase-Escalante National Monument and the case for its protection."
embedUrl: "https://experience.arcgis.com/experience/75e15b0fff54472c93ca174e7edd143c/"
order: 3
---

Replace this with your write-up on the Grand Staircase-Escalante threat — what's proposed, what's at stake, and how people can act.
